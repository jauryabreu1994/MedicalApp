﻿using MedicalApp.Context;
using MedicalApp.Models.Enums;
using System;
using System.Linq;
using System.Web.Mvc;
using System.Data;
using System.Data.Entity;
using System.Web;

namespace MedicalApp.Controllers
{
    public class GenericController :  Controller
    {
        public string SetFormatVatNumber(string VatNumber)
        {

            if (new String(VatNumber.Where(Char.IsLetter).ToArray()).Length == 0)
            {
                if (VatNumber.Length == 9)
                {
                    VatNumber = Convert.ToInt64(new String(VatNumber.Where(Char.IsDigit).ToArray())).ToString("###-#####-#");
                }
                else if (VatNumber.Length == 11)
                {
                    VatNumber = Convert.ToInt64(new String(VatNumber.Where(Char.IsDigit).ToArray())).ToString("###-#######-#");
                }
            }

            return VatNumber;
        }

        public bool hasAccess(PermisoEnum permiso, HttpSessionStateBase session, bool isUser = true) 
        {
            try
            {
                MainDbContext db = new MainDbContext();
                Encriptar_DesEncriptar encriptar_DesEncriptar = new Encriptar_DesEncriptar();

                if (session["UserID"] != null)
                {
                    if (isUser)
                    {
                        int UserID = Convert.ToInt32(encriptar_DesEncriptar.DesEncriptar(session["UserID"].ToString()));
                        int GrupoUsuarioId = Convert.ToInt32(encriptar_DesEncriptar.DesEncriptar(session["GrupoUsuarioId"].ToString()));

                        var grupoPermisos = db.GrupoPermiso.Include(e => e._GrupoUsuario).Include(e => e._Permiso).Where(a => a.GrupoUsuarioId == GrupoUsuarioId).ToList();

                        return grupoPermisos.Where(a => a.PermisoId == (int)permiso).Count() == 0 ? false : true;
                    }
                    else {
                        int UserID = Convert.ToInt32(encriptar_DesEncriptar.DesEncriptar(session["UserID"].ToString()));
                        int GrupoUsuarioId = Convert.ToInt32(encriptar_DesEncriptar.DesEncriptar(session["GrupoUsuarioId"].ToString()));

                        return GrupoUsuarioId != 99 ? false : true;
                    }
                }
                return false;
            }
            catch (Exception) 
            {
                return false;
            }
        }
    }
}