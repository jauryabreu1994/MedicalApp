﻿
namespace MedicalApp.Models.Enums
{
    public enum CompanyEnum
    {
        Servicio = 0,
        Cliente = 1,
        Cita = 2,
        Transaccion = 3,
        Cierre = 4,
        Doctor = 5,
        Enfermera = 6,
        Administrativo = 7,
    }
}
