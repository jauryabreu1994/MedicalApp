﻿
namespace MedicalApp.Models.Enums
{
    public enum EstadoEnum
    {
        Inactivo = 0,
        Activo = 1,
        Public = 2,
        Privado = 3,
        Pendiente = 4,
        Completa = 5
    }
}