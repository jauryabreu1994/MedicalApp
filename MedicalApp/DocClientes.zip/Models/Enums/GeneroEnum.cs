﻿
namespace MedicalApp.Models.Enums
{
    public enum GeneroEnum
    {
        Masculino = 0,
        Femenino = 1,
        Otro = 2
    }
}