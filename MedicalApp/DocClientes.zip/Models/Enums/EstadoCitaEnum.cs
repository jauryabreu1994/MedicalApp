﻿
namespace MedicalApp.Models.Enums
{
    public enum EstadoCitaEnum
    {
        Cancelada = 0,
        Confirmada = 1,
        PendientePago = 2,
        EnEspera = 3,
        Pendiente = 4,
        Completada = 5,
    }
}