﻿
namespace MedicalApp.Models.Enums
{
    public enum TipoPagoEnum
    {
        Venta = 0,
        Devolucion = 1,
        Todos = 2
    }
}