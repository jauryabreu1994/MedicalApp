﻿
namespace MedicalApp.Models.Enums
{
    public enum TipoCitaEnum
    {
        Consulta = 0,
        VerificacionAnalisis = 1,
        Cirugia = 2,
    }
}