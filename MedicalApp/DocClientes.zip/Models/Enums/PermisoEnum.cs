﻿
namespace MedicalApp.Models.Enums
{
    public enum PermisoEnum
    {
        Empresa = 1,
        Usuario = 2,
        Servicios = 3,
        Clientes = 4,
        Transacciones = 5,
        Habitaciones = 6,
        Citas = 7,
        Perfil = 8,
    }
}