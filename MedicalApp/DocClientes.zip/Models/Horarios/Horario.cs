﻿namespace MedicalApp.Models.Horarios
{
    public class Horario : MainModel
    {
        public int Hora { get; set; } = 8;
        public int Minutos { get; set; } = 0;
    }
}